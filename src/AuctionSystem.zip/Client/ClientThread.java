package Client;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClientThread extends Thread{
	private Socket msgSocket = null;
	private BufferedReader in;
	public String msg = "";
	public int clientId = -1;
	public boolean quit = false;
	
	public ClientThread(Socket socket) throws IOException{
		msgSocket = socket;
		in = new BufferedReader(new InputStreamReader(
	                     msgSocket.getInputStream()));
	}
	
	public void run(){
		while(true){
			try {
				if(in.ready()){
					msg = in.readLine();
					//int l = msg.length();	
					if(msg != null && msg.contains("Your id is")){
						clientId = Integer.parseInt(msg.split("#")[1]);
						yield();
						msg = msg.replace("#", "");
					}
					System.out.println("----------------------------");
					System.out.println(msg);
					
					if("You have unregistered. Bye!".equals(msg)){
						quit = true;
						msgSocket.close();
						break;
					}
					msg = "";
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.exit(0);
	}
}
